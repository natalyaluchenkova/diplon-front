import React from "react";
import SimpleSlider from "./SimpleSlider";
import "../css/home.css"

function Main() {
    return (
        <div className="slider">
            <SimpleSlider />
        </div>
    );
}

export default Main;