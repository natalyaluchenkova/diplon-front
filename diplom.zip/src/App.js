import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from './Components/Header';
import Main from './Components/Main';
import Footer from './Components/Footer';
import './index.css';


function App() {
  return (
    <BrowserRouter>
      <Header /> 
      <main className='middle'>
        <Main />
      </main> 
      <Footer />
    </BrowserRouter>
  );
}

export default App;
